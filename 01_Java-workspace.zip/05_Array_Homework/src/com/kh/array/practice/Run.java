package com.kh.array.practice;

public class Run {
	public static void main(String[] args) {
		ArrayPractic ap = new ArrayPractic();
		ap.parcitce1();
	}

}
