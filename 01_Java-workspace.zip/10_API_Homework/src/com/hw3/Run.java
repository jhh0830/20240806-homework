package com.hw3;
import java.util.Date;
import com.hw3.controller.SetDate;

public class Run {

	public static void main(String[] args) {

		SetDate tw1 = new SetDate();
		tw1.todayPrint();
		tw1.setDay();
		
		
	}

}
