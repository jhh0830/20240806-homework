package practice2.model.vo;

public interface Camera {
	

	void picture();

	
}
