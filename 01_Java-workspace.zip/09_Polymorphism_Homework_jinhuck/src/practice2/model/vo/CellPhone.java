package practice2.model.vo;

public interface CellPhone extends Phone, Camera {
	public void charge();
}
