package practice2.model.vo;

public abstract class  SmartPhone implements CellPhone, TouchDisplay{
	SmartPhone(){};
	
	
	public abstract void  printMaker();
}