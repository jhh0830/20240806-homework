package com.kh.chap02.practice.example;

import java.util.Scanner;

public class LoopPractice {
	public void parctice5() {
		Scanner sc =new Scanner(System.in);
		System.out.print("������ �ϳ� �Է��ϼ��� : ");
		int num = sc.nextInt();
		sc.nextLine();
		int sum = 0;
		
		for(int i = 1; i<num; i++) {
			
				System.out.printf(i + " + ",num);
				sum += i;
			}
		System.out.println(" = " + sum);
		}
	
}
