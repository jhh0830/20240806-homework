package com.kh.chap02.practice.run;

import com.kh.chap02.practice.example.LoopPractice;

public class Run {
	public static void main(String[] args) {
		 LoopPractice lp = new LoopPractice();
		 lp.parctice5();
	}
}
