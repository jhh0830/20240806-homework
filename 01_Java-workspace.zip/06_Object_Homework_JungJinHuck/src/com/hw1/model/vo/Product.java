package com.hw1.model.vo;

public class Product {
	private String productId;
	private String productName;
	private String puroutcArea;
	private int price;
	private double tax;
	
	
	
	
public void product(String productId, String productName, String puroutcArea, int price, double tax) {
		
		
	this.price = price;
		
		
	}
}
