package homework_mvc.run;

import homework_mvc.view.EmployeeView;

public class EmployeeRun {

	public static void main(String[] args) {
		
		EmployeeView ev = new EmployeeView();
		ev.mainList();
	}

}
