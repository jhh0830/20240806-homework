package homework_mvc.model.vo;

public class Employee {

	private String name; //��� �̸�
	private String spot; // ����
	private int  year;// ����
	
	public Employee() {
		
	}
	public Employee(String name, String spot, int year) {
		super();
		this.name = name;
		this.spot = spot;
		this.year = year;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSpot() {
		return spot;
	}
	public void setSpot(String spot) {
		this.spot = spot;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	@Override
	public String toString() {
		return "�����  [�̸�=" + name + ", ����=" + spot + ", ����=" + year + "]";
	}
	
	
	
}
