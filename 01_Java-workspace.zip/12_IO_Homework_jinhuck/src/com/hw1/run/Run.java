package com.hw1.run;

import java.util.Scanner;

import com.hw1.model.dao.FileDao;

public class Run {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		FileDao  fd = new FileDao();
		
	}

}
